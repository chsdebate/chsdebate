<?php
$user = "admin";
$password = "admin";
$server = "localhost";
$db = "debate";

$dbconnect = mysqli_connect($server, $user, $password, $db);
?>