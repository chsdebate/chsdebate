<?php
error_reporting(0);
session_start();
// remove all session variables
session_unset();
// destroy the session
session_destroy();
include 'scripts/php/dbconnect.php';
$error = $_GET['error'];
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Century Debate Team</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/simple-sidebar.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script src="js/formvalid.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <?php include 'scripts/php/nav.php'; ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <?php
                    if (isset($error)){
                        if($error == 1){
                    ?>
                                    <strong>Password Confirmation Failed</strong>
                    <?php
                    }
                        elseif($error == 2){
                    ?>
                                    <strong>Username not found</strong>
                    <?php
                        }
                        elseif($error == 3){
                    ?>
                                    <strong>Password does not match record</strong>
                    <?php
                        }
                        elseif($error == 4){
                    ?>
                                    <strong>Username on Record</strong>
                    <?php
                        }
                        elseif($error == 0){
                    ?>
                                    <strong>SUCCESS!!!</strong>
                    <?php
                        }
                        elseif($error == 5){
                    ?>
                                    <strong>Couldn't add some salt to that pepper</strong>
                    <?php
                        }
                        else{}
}
                    else{}
                    ?>
                    <div id="Sign-In">
                        <fieldset style="width:30%"><legend>Please Login</legend>
                        <form method="POST" action="login_engine.php">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" class="form-control" name="user">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" name="pass">
                            </div>
                        <br>
                            <button type="submit" class="btn btn-success">Log-In</button>
                        </form>
                        </fieldset>
                    </div>
                    <div id="register">
                        <fieldset style="width:30%"><legend>Please Register if not already</legend>
                        <form name="register" method="POST" action="register_engine.php" onsubmit="return validateForm()">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" class="form-control" name="userreg" required>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <label>UpperCase, LowerCase, Number/SpecialChar and min 8 Chars</label>
                                <input type="password" class="form-control" name="passreg" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" required>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" class="form-control" name="passconreg" required>
                            </div>
                        <br>
                            <button type="submit" class="btn btn-info">Register</button>
                        </form>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>